# Hírfigyelő modul — fejlesztői átadó (első felületvázlat)

Kattintható prototípus: `Hirfigyelo-prototipus.dc.html` (helyi webszerverről, lásd INDITAS.md). Három főoldal: Áttekintés · Figyelés beállítása · Finomhangolás — nincs külön dashboard, riportközpont vagy varázsló. A részletek oldalsó, visszazárható panelben nyílnak (mobilon teljes szélességű overlay), nem negyedik oldalon.

## Vizsgálati kérdés
„A felhasználó gyorsan megérti-e, miért kapta ezeket a találatokat, és kevés munkával el tudja-e érni, hogy legközelebb jobbakat kapjon?" — ezt szolgálja: minden találaton „Miért fontos neked?" indoklás + téma-címke + egyszerű fontossági kategória (nincs ál-pontos százalék); a Finomhangolásban két kattintásos visszajelzés → konkrét, indokolt AI-módosítási javaslat.

## Komponensjegyzék
- **StatusStrip** — utolsó/következő futás (időzónával), új találatok, részleges hiba chip, kézi futtatás; futás közben háttér-jelzés (oldalváltás nem szakítja meg, dupla indítás tiltva, nincs kitalált százalék).
- **AiOverview** — forrásokra hivatkozó összkép; bizonytalan/ellentmondó forrásnál nem von le biztos következtetést (felirat + viselkedési szabály).
- **HitCard** — cím, forrás(ok)+idő, összefoglaló, „Miért fontos neked?", témacímke, fontosság (Fontos/Érdekes/Háttér), Mentés / Nem releváns / Részletek; azonos eseményről szóló cikkek egy kártyán, forrásszám-jelzéssel; v-címke (melyik szabályváltozattal készült).
- **DetailPanel** — hosszabb összefoglaló, eredeti link, több forrás, értékelés indoklása, igény szerinti tartalomötlet (AI-javaslatként elkülönítve; nem generálódik automatikusan).
- **SetupForm** — célok, szabad szöveg → strukturált beállítás, témák/névváltozatok/megkülönböztetés-példa/területi-nyelvi fókusz/kizárások; nem kér operátor-szintaxist.
- **SourceList** — kézi + AI-javasolt források; állapot: ellenőrzés alatt / használható / korlátozott / hibás; AI-javaslat ellenőrzés előtt nem „ellenőrzött"; utolsó feldolgozás + hibaok.
- **Scheduler** — kézi / napi automatikus, időpont + időzóna; e-mail-összefoglaló csak jövőbeli bővítésként jelölve.
- **TrialRun** — korlátozott minta; eredmény a Finomhangolás oldalon, a beállításváltozathoz kötve. Módosítás = tervezet; a futó figyelést csak a mentés váltja.
- **FeedbackCard** — Fontos nekem / Nem releváns + max. 4 érthető ok + saját indok; mentés/megnyitás nem hoz létre szabályt.
- **RuleSuggestion** — jelenlegi szabály / javasolt változtatás / mely visszajelzések alapján / várható hatás; Kipróbálom (azonos mintán összehasonlítás, „nem állítunk általános javulást" felirattal) / Elfogadom / Elvetem.
- **VersionList** — verziózott szabályok, visszaállítás; a korábbi találatok nem íródnak át (v-címke).
- **ProfileTouch** — a közös profilt érintő visszajelzésnél átirányítás a profil szerkesztéséhez; a modul nem írja át a cégprofilt.

## Bemutatott állapotok
első használat (nincs aktív figyelés) · AI-előkészített, nem jóváhagyott beállítás · próbafutás folyamatban · siker új találatokkal · siker új találat nélkül (vizuálisan elkülönül a hibától) · részleges forráshiba · AI-kiesés (begyűjtött anyag megvan, értékelés függőben) · sikertelen mentés · finomhangolási javaslat elfogadás előtt · új szabályverzió + visszaállítás. Vezérlés: bal alsó Prototípus-vezérlők.

## Adatkapcsolatok és modulhatárok
Rétegek, egymástól elválasztva: (1) figyelési mag (begyűjtés, deduplikáció, relevancia-értékelés); (2) konfiguráció + szabályverziók (verziózott, visszaállítható); (3) felület (3 oldal, tokenekből); (4) csatlakozók: AI-, tárolási, forrásfeldolgozási, időzítési adapterek; (5) host-adapter: ügyfélprofil + jogosultságok a befogadó alkalmazástól. A modul nem függ konkrét SaaS-menütől, ügyféltől vagy adatbázistáblától; önálló használatban minimális host adja a fiókot és a közös profilt (a meglévő közös onboarding indítható előtte — nincs második cégbemutatkozás). Éles használatra verziózott csomagként, nem fájlmásolással.

## Theme és nyelvek
A közös témarendszert használja (tema-alap.json + km-theme.js) — beégetett szín/betű/lekerekítés nincs, minden var(--token); külön hírfigyelő-témamotor nincs. Új közös tokent nem igényelt. Az ügyfél brandprofilja nem témázza a kezelőfelületet. Felületi nyelvek: HU/RO/EN a hf-i18n.js központi állományból (hu tartalék; új nyelv/RTL később). A forrás eredeti nyelve, az összefoglaló és a tartalomötlet nyelve külön jelölt; a fordítás nem írja felül az eredetit.

## Mintaadatok
Két fiktív profil: Minta Műhely (bútorműhely — fő példa) és Dr. Szabó Anna (személyes márka — személyre szabhatóság). Minden demóhír [MINTA] jelölésű, kitalált; nem valódi sajtóesemény. Névütközés-példák: „Minta Műhely" étterem, Szabó Anna ügyvéd.

## Szimulált vs. működő
**Működik:** a 3 oldal teljes állapotgépe, szűrők, visszajelzés→javaslat→verzió folyamat, összehasonlítás, visszaállítás, részletpanel (lista-pozíció és szűrő megőrzésével), i18n, tokenöröklés. **Szimulált:** begyűjtés, deduplikáció, AI-értékelés/összkép/ötlet (időzített, beégetett minták), forrásellenőrzés, ütemezés, mentés. Valódi API-kulcsot a felület nem kér.

## Nyitott döntések
Relevancia-értékelés módszere és a fontossági kategóriák küszöbei · deduplikációs stratégia · forrásellenőrzés mélysége (robots, jogi keretek) · keresőszolgáltatás-bekötés (bővítés) · e-mail-összefoglaló (bővítés) · a szabályverziók tárolása a központi profilban · a hostjogosultsági szerződés részletei · RO/EN szótár lektorálása.
