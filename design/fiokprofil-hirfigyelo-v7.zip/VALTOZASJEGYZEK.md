# Változásjegyzék — v5 → v6 (célzott technikai javítás)

## Nyelvek
- Kötelező induló nyelvek: HU, RO, **EN** — teljes angol szótár (onboarding, Theme, állapotok, hozzáférhetőségi címkék, AI-szövegek, hibák). Az AR + RTL bővíthetőségi példaként megmaradt, nem átadási feltétel.
- A km-theme.js validátora nem ad többé magyar szöveget: strukturált {token, code, params} hibát ad, a felület a választott nyelven fogalmazza meg (km-i18n val* kulcsok, mind a 4 nyelven).

## Színvalidáció
- Teljes értékű ellenőrzés: `rgb(nemszin` és `oklch(hibas` elutasítva (egységteszttel igazolva). Támogatott formátumok: #rgb/#rrggbb/#rrggbbaa, rgb(), rgba(), hsl(), hsla() — számtartomány-ellenőrzéssel; minden elfogadott formátumot kezel a parser, a kontrasztellenőrzés és az előnézet. Nem támogatott formátum (oklch, névszín) érthető hibával elutasítva. Verzió-, objektumtípus-, tartomány- és enum-ellenőrzés megmaradt.

## Arculati verziómegőrzés
- Jóváhagyáskor teljes, változatlan pillanatkép tárolódik verziónként (forrás- és jóváhagyási adatokkal); szerkesztés új tervezetet nyit, amely nem érinti a jóváhagyott példányt; „Tervezet elvetése" visszaállítja a korábbi jóváhagyott állapotot; az új jóváhagyás konkrét verzióhoz kötött. A megőrzés munkamenet-memóriában él — nem tartós adatbázis (dokumentálva).

## Beégetett értékek
- A derive()-ből kikerült a fix fekete színkeverés (→ --shadow-color), a fix sorköz, elemköz és gombpadding (→ --lh, --gap, --btn-pad-y/x tokenek) és a fix üveg-telítettség (→ --sat-glass); mind szerkeszthető a Theme-oldal Részletes beállításai közt. A Theme-előnézet komponenseiből a saját alapértékek (fallbackok) kikerültek — az előnézet csak betöltött témával renderel.

## Indítás és betöltés
- INDITAS.md: előfeltétel, könyvtár, parancs (python3 -m http.server / npx serve), címek. Nincs csendes hibalenyelés: betöltési állapot, lokalizált hibaüzenet, újrapróbálás; sikertelen betöltésnél mentés/alkalmazás letiltva — hiányos konfiguráció nem írhat felül működő témát.

## Ellenőrzés
- ELLENORZES.md: a 10 tétel elvégzett/részleges/nem ellenőrzött jelöléssel és módszerrel.
