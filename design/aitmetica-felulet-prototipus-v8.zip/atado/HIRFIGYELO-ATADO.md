# Hírfigyelő modul — fejlesztői átadó (első felületvázlat)

Kattintható prototípus: `Hirfigyelo-prototipus.dc.html` (helyi webszerverről, lásd INDITAS.md). Három főoldal: Áttekintés · Figyelés beállítása · Finomhangolás — nincs külön dashboard, riportközpont vagy varázsló. A részletek oldalsó, visszazárható panelben nyílnak (mobilon teljes szélességű overlay), nem negyedik oldalon.

## v2 működési pontosítások (a jelen változatban működnek)
- **Piszkozat ≠ aktív beállítás:** a szerkesztés külön piszkozatban él („Nem mentett módosítások" jelzéssel a fejlécen és a Beállítás oldalon); az aktív futást csak a mentés váltja. Változatlan beállítás mentése nem hoz létre új verziót.
- **Teljes verzió-pillanatképek:** minden verzió a célok/témák/kizárások/források/ütemezés/időzóna + ügyfélprofil-hivatkozás teljes másolata. Visszaállítás = a beállítások tényleges visszaállítása ÚJ verzióként, az eredeti megőrzésével. A finomhangolási javaslat csak elfogadáskor hoz létre új aktív verziót. (A tárolás munkamenet-memória — nem tartós adatbázis.)
- **Futás ≠ mentés:** a beállításmentés, a forrásellenőrzés és az AI-feldolgozás külön esemény. Az „Utolsó sikeres ellenőrzés" tárolt időpont + verziószám; sikertelen próbálkozás nem írja felül (külön sor jelzi). A következő futás az AKTÍV ütemezésből számít, nem a mentetlen szerkesztésből.
- **Új/megtekintett/mentett/elrejtett külön állapot:** a részletek megnyitása megtekintettnek jelöl; van „Összes megjelölése megtekintettként"; ismételt futás nem újrázza ugyanazt a találatot. A találat örökre őrzi, melyik futás/szabályverzió hozta létre.
- **AI-kiesés:** a begyűjtött hírek „AI-feldolgozásra vár" jelöléssel láthatók; nem készül látszólag sikeres összefoglaló; a tartalomötlet-kérés hibával tér vissza (újrapróbálható); a korábbi eredmények olvashatók.
- **Próbafutás:** a piszkozat rögzített pillanatképén fut; ha a piszkozat utána módosul, a Finomhangolás jelzi, hogy az eredmény korábbi változatot vizsgált.
- **Forrásfelvétel cím beillesztésével:** a rendszer vizsgálja a követhetőséget (RSS-felismerés · RSS nélküli weboldalnál figyelendő szakasz kiválasztása · saját Facebook-oldalnál hivatalos csatlakoztatás jogosultság-ellenőrzéssel · más Facebook-oldalánál külső hozzáférés jelzése, ígéret nélkül · nem támogatott cím elutasítva). Hozzáférés és működés külön állapot, közérthető hibaokkal és következő lépéssel; szerkesztés/szüneteltetés/eltávolítás forrásonként. Jelszót, böngészős munkamenetet, sütit sosem kér.
- **Alapnyelv: angol** (hu/ro teljes); minden új szöveg a hf-i18n.js-ben.

## Átadási ellenőrzés (mind kipróbálható)
1. Mentetlen ütemezésmódosítás nem változtatja a következő aktív futást (az Áttekintés az aktív verzióból számol). 2. Visszaállítás tényleges beállítás-visszaállítás új verzióként. 3. Régi találat v-címkéje változatlan marad. 4. Mentés nem jelenik meg sikeres ellenőrzésként. 5. Megtekintett hír nem lesz újra „új". 6. Csatlakoztatás nélküli Facebook-forrás nem „követhető". 7. AI-hiba alatt az ötletkérés hibára fut, nem látszatsikerre.

## Vizsgálati kérdés
„A felhasználó gyorsan megérti-e, miért kapta ezeket a találatokat, és kevés munkával el tudja-e érni, hogy legközelebb jobbakat kapjon?" — ezt szolgálja: minden találaton „Miért fontos neked?" indoklás + téma-címke + egyszerű fontossági kategória (nincs ál-pontos százalék); a Finomhangolásban két kattintásos visszajelzés → konkrét, indokolt AI-módosítási javaslat.

## Komponensjegyzék
- **StatusStrip** — utolsó/következő futás (időzónával), új találatok, részleges hiba chip, kézi futtatás; futás közben háttér-jelzés (oldalváltás nem szakítja meg, dupla indítás tiltva, nincs kitalált százalék).
- **AiOverview** — forrásokra hivatkozó összkép; bizonytalan/ellentmondó forrásnál nem von le biztos következtetést (felirat + viselkedési szabály).
- **HitCard** — cím, forrás(ok)+idő, összefoglaló, „Miért fontos neked?", témacímke, fontosság (Fontos/Érdekes/Háttér), Mentés / Nem releváns / Részletek; azonos eseményről szóló cikkek egy kártyán, forrásszám-jelzéssel; v-címke (melyik szabályváltozattal készült).
- **DetailPanel** — hosszabb összefoglaló, eredeti link, több forrás, értékelés indoklása, igény szerinti tartalomötlet (AI-javaslatként elkülönítve; nem generálódik automatikusan).
- **SetupForm** — célok, szabad szöveg → strukturált beállítás, témák/névváltozatok/megkülönböztetés-példa/területi-nyelvi fókusz/kizárások; nem kér operátor-szintaxist.
- **SourceList** — kézi + AI-javasolt források; állapot: ellenőrzés alatt / használható / korlátozott / hibás; AI-javaslat ellenőrzés előtt nem „ellenőrzött"; utolsó feldolgozás + hibaok.
- **Scheduler** — kézi / napi automatikus, időpont + időzóna; e-mail-összefoglaló csak jövőbeli bővítésként jelölve.
- **TrialRun** — korlátozott minta; eredmény a Finomhangolás oldalon, a beállításváltozathoz kötve. Módosítás = tervezet; a futó figyelést csak a mentés váltja.
- **FeedbackCard** — Fontos nekem / Nem releváns + max. 4 érthető ok + saját indok; mentés/megnyitás nem hoz létre szabályt.
- **RuleSuggestion** — jelenlegi szabály / javasolt változtatás / mely visszajelzések alapján / várható hatás; Kipróbálom (azonos mintán összehasonlítás, „nem állítunk általános javulást" felirattal) / Elfogadom / Elvetem.
- **VersionList** — verziózott szabályok, visszaállítás; a korábbi találatok nem íródnak át (v-címke).
- **ProfileTouch** — a közös profilt érintő visszajelzésnél átirányítás a profil szerkesztéséhez; a modul nem írja át a cégprofilt.

## Bemutatott állapotok
első használat (nincs aktív figyelés) · AI-előkészített, nem jóváhagyott beállítás · próbafutás folyamatban · siker új találatokkal · siker új találat nélkül (vizuálisan elkülönül a hibától) · részleges forráshiba · AI-kiesés (begyűjtött anyag megvan, értékelés függőben) · sikertelen mentés · finomhangolási javaslat elfogadás előtt · új szabályverzió + visszaállítás. Vezérlés: bal alsó Prototípus-vezérlők.

## Adatkapcsolatok és modulhatárok
Rétegek, egymástól elválasztva: (1) figyelési mag (begyűjtés, deduplikáció, relevancia-értékelés); (2) konfiguráció + szabályverziók (verziózott, visszaállítható); (3) felület (3 oldal, tokenekből); (4) csatlakozók: AI-, tárolási, forrásfeldolgozási, időzítési adapterek; (5) host-adapter: ügyfélprofil + jogosultságok a befogadó alkalmazástól. A modul nem függ konkrét SaaS-menütől, ügyféltől vagy adatbázistáblától; önálló használatban minimális host adja a fiókot és a közös profilt (a meglévő közös onboarding indítható előtte — nincs második cégbemutatkozás). Éles használatra verziózott csomagként, nem fájlmásolással.

## Theme és nyelvek
A közös témarendszert használja (tema-alap.json + km-theme.js) — beégetett szín/betű/lekerekítés nincs, minden var(--token); külön hírfigyelő-témamotor nincs. Új közös tokent nem igényelt. Az ügyfél brandprofilja nem témázza a kezelőfelületet. Felületi nyelvek: HU/RO/EN a hf-i18n.js központi állományból (hu tartalék; új nyelv/RTL később). A forrás eredeti nyelve, az összefoglaló és a tartalomötlet nyelve külön jelölt; a fordítás nem írja felül az eredetit.

## Mintaadatok
Két fiktív profil: Minta Műhely (bútorműhely — fő példa) és Dr. Szabó Anna (személyes márka — személyre szabhatóság). Minden demóhír [MINTA] jelölésű, kitalált; nem valódi sajtóesemény. Névütközés-példák: „Minta Műhely" étterem, Szabó Anna ügyvéd.

## Szimulált vs. működő
**Működik:** a 3 oldal teljes állapotgépe, szűrők, visszajelzés→javaslat→verzió folyamat, összehasonlítás, visszaállítás, részletpanel (lista-pozíció és szűrő megőrzésével), i18n, tokenöröklés. **Szimulált (a prototípusban időzített, beégetett mintákkal, de következetes állapotváltással):** begyűjtés, deduplikáció, AI-értékelés/összkép/ötlet, forrástípus-felismerés és -ellenőrzés, Facebook-csatlakoztatás, ütemezés, mentés. **Valódi háttérszolgáltatást igényel:** RSS-/weboldal-feldolgozó, platform-API-integráció (Facebook oldalkezelői engedélyekkel), AI-szolgáltató, tartós verzió- és futástörténet-tár, ütemező. Valódi API-kulcsot a felület nem kér.

## Nyitott döntések
Relevancia-értékelés módszere és a fontossági kategóriák küszöbei · deduplikációs stratégia · forrásellenőrzés mélysége (robots, jogi keretek) · keresőszolgáltatás-bekötés (bővítés) · e-mail-összefoglaló (bővítés) · a szabályverziók tárolása a központi profilban · a hostjogosultsági szerződés részletei · RO/EN szótár lektorálása.
