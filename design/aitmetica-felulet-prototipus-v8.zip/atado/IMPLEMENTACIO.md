# Kommunikációs munkatér — onboarding átadó (v6)

Kattintható prototípusok + implementációs utasítások. A HTML-fájlok böngészőben nyithatók (a `support.js`, `km-theme.js`, `km-i18n.js`, `tema-alap.json` legyen mellettük).

## Fájlok
- `Onboarding-prototipus v6.dc.html` — onboarding (3 lépés, arculati profil, i18n).\n- `Fiokprofil-optimalizalt.dc.html` — a befogadó alkalmazás fiókprofil-oldalának optimalizált mockupja (2026-os calm-design elvek: kompakt fejléc státusszal, kétoszlopos mezőrács, halk hiányjelzés, összevont oldalsáv; az eredetjelvények és eredet-részletek változatlanul). Referencia-irány a fő alkalmazás profilfelületéhez — nem az onboarding része.
- `Hirfigyelo-prototipus.dc.html` + `hf-i18n.js` + `HIRFIGYELO-ATADO.md` — hír- és sajtófigyelő modul első vázlata (3 főoldal, közös tokenek és profil, HU/RO/EN).
- `INDITAS.md` — helyi futtatás (webszerver szükséges a tema-alap.json betöltéséhez); `ELLENORZES.md` — ellenőrzési jegyzék.
- `Theme-beallitasok.dc.html` — Theme-kezelő (típusos import-validáció, i18n/RTL).
- `tema-alap.json` — az EGYETLEN karbantartott alap-témadefiníció (mindkét oldal futásidőben ezt tölti).
- `km-theme.js` — tokenséma, típusos validate(), derive() származtatás, KM_BRAND_DEFAULTS.
- `km-i18n.js` — központi nyelvi állomány. Kötelező első kiadási nyelvek: **HU, RO, EN** (teljes lefedettség: onboarding, Theme, állapotok, hozzáférhetőségi címkék, AI-szövegek, hibák, validációs üzenetek). Az **AR + RTL** bővíthetőségi példa marad, nem átadási feltétel. A validátor strukturált hibakódot ad ({token, code, params}), a szöveget a felület lokalizálja.
- `brandprofil-minta.json` — fiktív brandprofil, állapotgéppel és verziózással.
- `Stilus-mintalap.dc.html` — fejlesztői token-/komponensminták (csak hu; dokumentáltan dev-oldal).
- `Fejlesztoi-jegyzetek.dc.html`, `VALTOZASJEGYZEK.md`; v4/v3 referenciaként.

## Ténylegesen működik / szimulált / későbbi implementáció
**Működik a prototípusban:** központi témázhatóság (egyetlen tema-alap.json; szín, betűcsalád — kód- és arab betű is —, betűvastagság, méretskála, lekerekítések 0-tól kapszuláig, keretvastagság, térköz, kattintási minimum, üveg-elmosás/erősség, árnyékszín és -erősség, mozgás); típusos témaimport tokenenkénti hibaüzenettel; tervezet ≠ alkalmazás; kontraszt-figyelmeztetés; teljes hu/ro/en felület (+ ar RTL példaként), nyelvváltás adatvesztés nélkül; brand-előnézet a SaaS-témától elkülönítve, saját szerkeszthető adatokkal és állapotgéppel; a teljes onboarding-állapotgép (mentés, hibák, pending-javaslatok, eredetkövetés).
**Szimulált:** AI-műveletek (kimenetek nyelvi állományból), URL-/dokumentumfeldolgozás, fájlfeltöltés, mentés (időzített), témaszolgáltatás (localStorage a központi API helyett), brandverziók tárolása (memóriában).
**Későbbi implementáció:** téma- és copy-adminfelület backendje, valódi AI- és mentés-csatlakozók, brandprofil-renderelő sablonok, fiók/piszkozat/átadás sorrend, teljes fordítási munkafolyamat.

## 1. Témarendszer (szerződés)
- Komponensben NINCS közvetlen szín-, betű-, vastagság-, lekerekítés-, árnyék- vagy effektérték — sem inline, sem JS-stílusban. Minden `var(--token)`; a konkrét értékek egy helyen: `tema-alap.json`.
- Származtatott tokenek (`km-theme.js derive()`): kizárólag konfigurálható bemenetekből — az árnyék a `--shadow-color` + `--shadow-strength`, a sikergradiens sötétítése is a `--shadow-color` tokenből; a sorköz (`--lh`), elemköz (`--gap`), gombpadding (`--btn-pad-y/x`) és üveg-telítettség (`--sat-glass`) mostantól szerkeszthető alaptoken (Theme-oldal, Részletes beállítások).
- Nyelvfüggő betűk: `--font-display/-body` (latin), `--font-display-arab/-body-arab`; az aktív `--font-*-active` a felület nyelvéből származik. Kódszövegek: `--font-code`.
- Ritkább beállítások a Theme-oldal „Részletes beállítások" szekciójában.
- Import-validáció típusonként, strukturált hibakódokkal: **támogatott színformátumok: #rgb/#rrggbb/#rrggbbaa, rgb(), rgba(), hsl(), hsla()** — a teljes érték ellenőrzött (pl. `rgb(nemszin` elutasítva), és minden elfogadott színt a színválasztó-környezet, az előnézet, az export és a kontrasztellenőrzés is kezel; a nem támogatott formátum (pl. oklch, névszín) érthető hibával elutasított. Px-méret tartománnyal (negatív tiltva), enum-készlet, betű-stack, `tokens` valódi objektum (tömb/null elutasítva), `$schema`-verzió. Ismeretlen token kihagyva, látható jelzéssel. Hibás import sem a tervezetet, sem az alkalmazott témát nem módosítja; a hiba tokent + javítási módot nevez meg, a felület nyelvén. Import csak előnézetbe; alkalmazás külön művelet.

## 2. Brand-elkülönítés
Két megjelenési tartomány: a kezelőfelület (mezők, címkék, gombok) a SaaS-témát használja; az ügyfélkreatív (mintakártya) KIZÁRÓLAG a brandprofilból + `KM_BRAND_DEFAULTS` semleges alapértékekből épül — SaaS-tokent nem örököl (betűt és lekerekítést sem). A SaaS-téma módosítása nem hat a kreatívra és fordítva. Hiányzó brandérték → semleges alapérték, „ideiglenes megjelenítés" jelöléssel, nem mentődik szabályként.

Szerkeszthető brandadatok: színek, cím-/törzsbetű (tényleges betűválasztás; az AI szöveges iránymutatása — pl. „kontrasztos serif" — csak hint), képvilág, követendő/kerülendő, lekerekítési szabály, a mintakártya nyelve (saját írásiránnyal). Módosítás megőrzi az eredetet és új jóváhagyást igényel.

**Arculati állapotgép (egymást kizáró):** `none → draft → (deferred | approved)`; deferred: adatok megmaradnak, szabályként nem alkalmazhatók; approved: nincs „későbbre hagyom", csak szerkesztés és jóváhagyás-visszavonás. **Verziómegőrzés:** jóváhagyáskor a teljes arculat pillanatképe eltárolódik az adott verzióhoz (forrás- és jóváhagyási adatokkal); jóváhagyott szerkesztése ÚJ tervezetet nyit (version+1), amely nem érinti a pillanatképet; a tervezet elvethető — ilyenkor a korábbi jóváhagyott állapot áll vissza; az új jóváhagyás konkrét verzióhoz kötődik. A megőrzés a prototípusban CSAK az aktuális munkamenetre érvényes (memória) — nem tartós adatbázisos verziózás; élesben verziótörténet a központi profilban.

## 3. Többnyelvűség és RTL
- Három külön beállítás: a felület nyelve (km-ui-lang, első képernyőn váltható, böngészőnyelv csak induló javaslat) · a kommunikáció tartalomnyelvei (profiladat) · az egyes tartalmak nyelve (pl. mintakártya). Nem írják felül egymást; arab felület mellett is készülhet magyar/román tartalom.
- Minden felhasználói szöveg stabil kulccsal a `km-i18n.js` központi állományból (mezők, gombok, hibák, mintaszövegek, hozzáférhetőségi címkék, Theme-feliratok). Hiányzó fordítás → hu tartaléknyelv, sosem nyers kulcs. Új nyelv = új szótár, képernyő-újraírás nélkül.
- Dátum/szám: `Intl` a nyelvi környezet szerint (mentési idő, lépésszám); nyelvnevek `Intl.DisplayNames`-szel lokalizálva.
- RTL: `dir` a gyökéren, irányfüggetlen (logical) elrendezési tulajdonságok — nincs külön arab képernyő. Irányjelzők (nyilak) a szótárból fordulnak; logók/nem irányjelző elemek nem tükröződnek. URL, e-mail, kód, tokenazonosító, JSON arab felületen is LTR (`dir="ltr"`, `unicode-bidi`). Beviteli mezők kevert arab–latin szöveget kezelnek. A brand-előnézet nyelve és iránya független a felületétől.
- Nyelvváltás kitöltés közben: az állapot érintetlen (csak a szótár és az aktív betűk váltanak); a mentett profiladatokat nem fordítja és nem írja felül.
- AI: kérdések/magyarázatok a felület nyelvén; kommunikációs minták a kiválasztott tartalomnyelven, látható nyelvjelöléssel; márkanevek és forrásszövegek fordítás nélkül.

## 4. Indítás és betöltés
Helyi webszerver szükséges (INDITAS.md: könyvtár, parancs, címek) — dupla kattintásos file:// megnyitásnál a témabetöltés jelzett hibaútra fut. A témabetöltésnek látható állapota van (betöltés / hiba + újrapróbálás, lokalizálva); sikertelen betöltésnél a Theme-oldalon a mentés és az alkalmazás letiltott, hiányos konfiguráció nem írhatja felül a működő témát. A .dc.html-ek :root tartalék CSS-blokkja a tema-alap.json generált tükre (build-lépés felelőssége, kézzel nem karbantartott téma).

## 5. Megőrzött működések
Pending-javaslat újrageneráláskor/finomításkor (elfogad/megtart, eredettel) · sikeroldal csak sikeres mentés után · mentést megváró kilépés · kézi továbbhaladás AI nélkül · forráshiba ≠ AI-hiba (külön szimuláció, a beviteli módtól függetlenül) · eredet + utolsó módosító · profile.open átadási pont · csökkentett mozgás a JS-animációkra is.

## Nyitott döntések
Márkanév · AI-szolgáltató, adatkezelés · fiók/piszkozat/átadás sorrend · minimum-feltétel · téma/copy/fordítás adminfelülete · brand-renderelők · fordítási munkafolyamat (a ro/ar szótár mintafordítás, nyelvi lektorálás szükséges).
