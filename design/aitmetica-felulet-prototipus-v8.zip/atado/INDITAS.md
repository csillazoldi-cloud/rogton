# Indítás — helyi futtatás

A prototípus `fetch('tema-alap.json')` hívással tölti be a közös témakonfigurációt, ezért **helyi webszerver szükséges** — a HTML-fájl dupla kattintásos (file://) megnyitása esetén a témabetöltés hibát jelez (ez a beépített hibaút, nem összeomlás: látható üzenet + újrapróbálás, mentés/alkalmazás letiltva).

## Előfeltétel
Modern böngésző (Chrome/Edge/Firefox/Safari, 2023+; a color-mix és :dir támogatás miatt) és egy tetszőleges statikus webszerver.

## Indítás
A kicsomagolt `atado` könyvtárból (ahol a .dc.html fájlok és a support.js, km-theme.js, km-i18n.js, tema-alap.json található):

    # Python 3
    python3 -m http.server 8080
    # vagy Node
    npx serve -l 8080 .

## Címek
- Hírfigyelő: http://localhost:8080/Hirfigyelo-prototipus.dc.html
- Onboarding: http://localhost:8080/Onboarding-prototipus%20v6.dc.html
- Theme-beállítások: http://localhost:8080/Theme-beallitasok.dc.html
- Stílus-mintalap: http://localhost:8080/Stilus-mintalap.dc.html

A nyelvválasztás (HU/RO/EN, + AR példa) és az alkalmazott téma a böngésző tárolójában marad meg (km-ui-lang, km-theme-applied, km-theme-draft kulcsok).
