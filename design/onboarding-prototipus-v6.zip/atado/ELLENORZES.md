# Ellenőrzési jegyzék — v6

Jelölés: [x] elvégzett · [~] részben · [ ] nem ellenőrzött. A módszer minden tételnél jelezve.

1. [~] Fő folyamat + Theme-oldal HU/RO/EN nyelven. — A teljes szótár mindhárom nyelven elkészült (km-i18n.js, azonos kulcskészlet, hu tartalék); a HU út böngészőben végigpróbálva, a RO/EN út szúrópróbaszerűen (nyelvváltás + fő képernyők). A RO/EN szöveg gépi mintafordítás, nyelvi lektorálás szükséges.
2. [x] Kitöltés közbeni nyelvváltás adatvesztés nélkül. — A nyelv csak a szótárt és az aktív betűtokent váltja; az állapot érintetlen (kódszinten garantált, böngészőben ellenőrizve).
3. [x] Hibás import üzenete a választott nyelven. — A validátor {token, code, params} hármast ad, a felület a km-i18n val* kulcsaiból fogalmaz (mindhárom nyelven + ar).
4. [x] `rgb(nemszin` és `oklch(hibas` elutasítva. — Izolált egységteszt lefuttatva a km-theme.js-en: mindkettő (és oklch általában, névszínek, tartományon kívüli rgb) elutasítva; #hex/rgb()/rgba()/hsl() elfogadva, kontrasztszámítás mindegyikre működik. Eredmény: ALL PASS.
5. [x] Érvényes téma export → visszaimport. — Az export a tokens készletet írja; a validátor ugyanazt a sémát ellenőrzi (egységteszt + böngészős próba).
6. [x] Jóváhagyott arculat módosításakor a korábbi verzió változatlan. — Jóváhagyáskor teljes pillanatkép tárolódik (brandVersions[v]); a szerkesztés új tervezetet nyit, a pillanatképet nem érinti. Csak munkamenet-memóriában — NEM tartós adatbázisos verziózás (dokumentálva).
7. [x] Tervezet elvetése visszaállítja a jóváhagyott állapotot. — „Tervezet elvetése" gomb a pillanatképből állít vissza, approved státusszal.
8. [x] Theme-módosítás nem változtatja a brandkreatívot. — A mintakártya kizárólag brandprofil-értékekből + KM_BRAND_DEFAULTS-ból épül, SaaS-tokent nem használ (kódszinten garantált, böngészőben ellenőrizve).
9. [x] Témakonfiguráció-betöltési hiba látható, újrapróbálható, nem ír felül. — Betöltési állapot + lokalizált hibaüzenet + újrapróbálás mindkét oldalon; hibánál mentés/alkalmazás letiltva (file:// megnyitással kipróbálható).
10. [x] Megmaradt: kézi javítás védelme (pending-javaslat), AI nélküli folytatás, mentéshez kötött sikerállapot. — Változatlan v5-logika, böngészőben szúrópróbázva.

**Nem ellenőrzött / részleges:** valódi mobil eszközön nem futott (a reszponzív egyoszlopos törés és a Theme-oldal mobil-előnézete böngésző-ablakszűkítéssel ellenőrizve); RO/EN/AR nyelvi minőség lektorálatlan; a böngészős vizuális ellenőrzés a fejlesztést kísérő automatikus felülvizsgálatra támaszkodik, pixelszintű kézi QA nem történt.
