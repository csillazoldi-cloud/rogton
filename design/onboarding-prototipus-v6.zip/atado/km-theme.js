// km-theme.js — közös témarendszer: séma, típusos validáció (strukturált hibakódokkal), származtatás.
// A validátor NEM ad vissza nyelvi szöveget: {token, code, params} hármast ad, a felület lokalizálja.
// A .dc.html-ek :root tartalék CSS-blokkja a tema-alap.json-ból generált tükör (build-lépés), kézzel nem karbantartott.
// Az alapértékek EGYETLEN forrása a tema-alap.json (futásidőben töltődik).
(function () {
  var SUPPORTED_VERSIONS = ['km-theme/2'];
  var SCHEMA = {
    '--bg': { type: 'color' }, '--bg-elev': { type: 'color' },
    '--text': { type: 'color' }, '--text-mut': { type: 'color' }, '--text-dim': { type: 'color' }, '--text-faint': { type: 'color' },
    '--on-primary': { type: 'color' }, '--primary': { type: 'color' }, '--primary-2': { type: 'color' },
    '--accent': { type: 'color' }, '--accent-text': { type: 'color' }, '--accent-link': { type: 'color' },
    '--ok': { type: 'color' }, '--err': { type: 'color' }, '--focus': { type: 'color' }, '--shadow-color': { type: 'color' },
    '--shadow-strength': { type: 'percent', min: 0, max: 80 },
    '--font-display': { type: 'font' }, '--font-body': { type: 'font' }, '--font-code': { type: 'font' },
    '--font-display-arab': { type: 'font' }, '--font-body-arab': { type: 'font' },
    '--fw-head': { type: 'enum', values: ['500', '600', '700', '800'] },
    '--fw-strong': { type: 'enum', values: ['500', '600', '700'] },
    '--fs-h1': { type: 'size', min: 20, max: 56 }, '--fs-base': { type: 'size', min: 12, max: 20 }, '--fs-title': { type: 'size', min: 14, max: 24 },
    '--r-card': { type: 'size', min: 0, max: 999 }, '--r-block': { type: 'size', min: 0, max: 999 },
    '--r-btn': { type: 'size', min: 0, max: 999 }, '--r-field': { type: 'size', min: 0, max: 999 }, '--r-badge': { type: 'size', min: 0, max: 999 },
    '--bw': { type: 'size', min: 0, max: 4 },
    '--pad-card': { type: 'size', min: 8, max: 64 }, '--pad-block': { type: 'size', min: 8, max: 40 },
    '--pad-field-y': { type: 'size', min: 6, max: 20 }, '--pad-field-x': { type: 'size', min: 8, max: 24 },
    '--control-min': { type: 'size', min: 32, max: 64 },
    '--blur-glass': { type: 'size', min: 0, max: 60 }, '--glass-alpha': { type: 'percent', min: 0, max: 30 },
    '--motion': { type: 'enum', values: ['normal', 'slow', 'off'] },
    '--lh': { type: 'num', min: 1.1, max: 2.2 },
    '--gap': { type: 'size', min: 4, max: 24 },
    '--btn-pad-y': { type: 'size', min: 8, max: 20 }, '--btn-pad-x': { type: 'size', min: 12, max: 40 },
    '--sat-glass': { type: 'percent', min: 50, max: 300 }
  };
  // Támogatott színformátumok: #rgb, #rrggbb, #rrggbbaa, rgb(), rgba(), hsl(), hsla().
  // Minden mást (pl. oklch, névvel adott szín) elutasítunk, hogy az előnézet, az export
  // és a kontrasztellenőrzés minden elfogadott színt kezelni tudjon.
  function parseColor(v) {
    if (typeof v !== 'string') return null;
    v = v.trim();
    var m = /^#([0-9a-fA-F]{3})$/.exec(v);
    if (m) { var h3 = m[1]; return [parseInt(h3[0] + h3[0], 16), parseInt(h3[1] + h3[1], 16), parseInt(h3[2] + h3[2], 16)]; }
    m = /^#([0-9a-fA-F]{6})([0-9a-fA-F]{2})?$/.exec(v);
    if (m) { var h = m[1]; return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
    m = /^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(0|1|0?\.\d+|1\.0)\s*)?\)$/.exec(v);
    if (m) { var r = +m[1], g = +m[2], b = +m[3]; if (r <= 255 && g <= 255 && b <= 255) return [r, g, b]; return null; }
    m = /^hsla?\(\s*(\d{1,3}(?:\.\d+)?)\s*,\s*(\d{1,3}(?:\.\d+)?)%\s*,\s*(\d{1,3}(?:\.\d+)?)%\s*(?:,\s*(0|1|0?\.\d+|1\.0)\s*)?\)$/.exec(v);
    if (m) {
      var H = +m[1], S = +m[2], L = +m[3];
      if (H > 360 || S > 100 || L > 100) return null;
      H /= 360; S /= 100; L /= 100;
      function f(n) { var kk = (n + H * 12) % 12; var a = S * Math.min(L, 1 - L); return L - a * Math.max(-1, Math.min(kk - 3, 9 - kk, 1)); }
      return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
    }
    return null;
  }
  function isColor(v) { return parseColor(v) !== null; }
  function luminance(v) {
    var rgb = parseColor(v);
    if (!rgb) return null;
    var c = rgb.map(function (x) { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }
  function contrast(a, b) {
    var l1 = luminance(a), l2 = luminance(b);
    if (l1 == null || l2 == null) return null;
    return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
  }
  // Strukturált hiba: { code, params } — a felület a km-i18n val.* kulcsaival lokalizálja.
  function checkToken(k, v) {
    var s = SCHEMA[k];
    if (!s) return { unknown: true };
    if (typeof v !== 'string' || !v.trim()) return { code: 'emptyValue', params: {} };
    if (v.indexOf('<') >= 0) return { code: 'badChar', params: {} };
    if (s.type === 'color') { if (!isColor(v)) return { code: 'badColor', params: { value: v } }; }
    else if (s.type === 'size') {
      var m = /^(-?\d+(?:\.\d+)?)px$/.exec(v);
      if (!m) return { code: 'badSize', params: { value: v } };
      var n = parseFloat(m[1]);
      if (n < 0) return { code: 'negative', params: { value: v, min: s.min } };
      if (n < s.min || n > s.max) return { code: 'outOfRange', params: { value: v, min: s.min, max: s.max } };
    }
    else if (s.type === 'percent') { var p = Number(v); if (!isFinite(p) || p < s.min || p > s.max) return { code: 'badPercent', params: { value: v, min: s.min, max: s.max } }; }
    else if (s.type === 'num') { var q = Number(v); if (!isFinite(q) || q < s.min || q > s.max) return { code: 'badNumber', params: { value: v, min: s.min, max: s.max } }; }
    else if (s.type === 'enum') { if (s.values.indexOf(v) < 0) return { code: 'badEnum', params: { value: v, values: s.values.join(', ') } }; }
    else if (s.type === 'font') { if (v.length > 120) return { code: 'badFont', params: {} }; }
    return null;
  }
  function validate(obj) {
    var errors = [], ignored = [];
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return { ok: false, errors: [{ token: '$', code: 'notObject', params: {} }], ignored: ignored };
    if (SUPPORTED_VERSIONS.indexOf(obj.$schema) < 0) errors.push({ token: '$schema', code: 'badVersion', params: { value: obj.$schema || '—', values: SUPPORTED_VERSIONS.join(', ') } });
    var tk = obj.tokens;
    if (!tk || typeof tk !== 'object' || Array.isArray(tk)) { errors.push({ token: 'tokens', code: 'tokensNotObject', params: {} }); return { ok: false, errors: errors, ignored: ignored }; }
    for (var k in tk) {
      var r = checkToken(k, tk[k]);
      if (r && r.unknown) ignored.push(k);
      else if (r) errors.push({ token: k, code: r.code, params: r.params });
    }
    return { ok: errors.length === 0, errors: errors, ignored: ignored };
  }
  function mix(c, pct, base) { return 'color-mix(in srgb, ' + c + ' ' + pct + '%, ' + (base || 'transparent') + ')'; }
  function derive(t, uiLang) {
    var ar = uiLang === 'ar';
    var fd = ar ? t['--font-display-arab'] : t['--font-display'];
    var fb = ar ? t['--font-body-arab'] : t['--font-body'];
    var a = t['--accent'], at = t['--accent-text'], txt = t['--text'];
    var ga = parseInt(t['--glass-alpha'] || '10', 10);
    var sh = mix(t['--shadow-color'], t['--shadow-strength'] || '45');
    var shSoft = mix(t['--shadow-color'], Math.round((parseInt(t['--shadow-strength'] || '45', 10)) * 1.1));
    var durs = t['--motion'] === 'off' ? ['0.001s', '0.001s', '0.001s', '0.001s', '0.001s']
      : t['--motion'] === 'slow' ? ['0.35s', '0.8s', '30s', '1.2s', '4s'] : ['0.2s', '0.45s', '18s', '0.7s', '2.5s'];
    return {
      '--font-display-active': fd, '--font-body-active': fb, '--font-code-active': t['--font-code'],
      '--grad-primary': 'linear-gradient(120deg,' + t['--primary'] + ',' + t['--primary-2'] + ')',
      '--grad-headline': 'linear-gradient(110deg,' + at + ',' + a + ')',
      '--accent-tint-weak': mix(a, 9), '--accent-tint': mix(a, 16), '--accent-tint-mid': mix(a, 28),
      '--accent-border': mix(a, 75), '--accent-border-soft': mix(a, 45),
      '--focus-ring': mix(t['--focus'], 30),
      '--glow-primary': mix(t['--primary'], 40), '--glow-primary-strong': mix(t['--primary-2'], 50),
      '--ok-strong': t['--ok'], '--ok-bg': mix(t['--ok'], 13),
      '--grad-ok': 'linear-gradient(140deg,' + t['--ok'] + ',' + mix(t['--ok'], 60, t['--shadow-color']) + ')', '--glow-ok': mix(t['--ok'], 45),
      '--err-strong': t['--err'], '--err-bg': mix(t['--err'], 10), '--err-border': mix(t['--err'], 30),
      '--err-btn-border': mix(t['--err'], 45), '--err-btn-bg': mix(t['--err'], 12),
      '--warn': at, '--warn-border': mix(at, 30), '--warn-bg': mix(a, 8),
      '--src-user': t['--ok'], '--src-user-bg': mix(t['--ok'], 13),
      '--src-web': t['--primary-2'], '--src-web-bg': mix(t['--primary-2'], 15),
      '--src-ai': at, '--src-ai-bg': mix(a, 20),
      '--src-empty': t['--text-faint'], '--src-empty-bg': mix(txt, 7),
      '--selection': mix(t['--primary'], 40),
      '--blob1': mix(a, 32), '--blob2': mix(t['--primary'], 24), '--blob3': mix(t['--primary-2'], 14),
      '--glass-bg': 'linear-gradient(160deg,' + mix(txt, ga) + ',' + mix(txt, Math.max(1, Math.round(ga * 0.35))) + ')',
      '--glass-border': mix(txt, 16),
      '--line': mix(txt, 10), '--line-soft': mix(txt, 7), '--line-dash': mix(txt, 15),
      '--field-bg': mix(txt, 5), '--field-border': mix(txt, 14),
      '--panel-soft': mix(txt, 2), '--panel-soft-2': mix(txt, 4),
      '--btn-ghost-bg': mix(txt, 5), '--btn-ghost-border': mix(txt, 14),
      '--btn-ghost-text': mix(txt, 85, t['--bg']), '--btn-ghost-hover': mix(txt, 10),
      '--btn-disabled-bg': mix(txt, 8),
      '--fs-md': (parseInt(t['--fs-base']) - 1) + 'px', '--fs-sm': (parseInt(t['--fs-base']) - 2) + 'px', '--fs-xs': (parseInt(t['--fs-base']) - 3) + 'px',
      '--dur-fast': durs[0], '--dur-med': durs[1], '--dur-amb': durs[2], '--dur-spin': durs[3], '--dur-flow': durs[4],
      '--glass-shadow': '0 24px 80px ' + sh + ', inset 0 1px 0 ' + mix(txt, 14),
      '--shadow-pop': '0 12px 32px ' + shSoft,
      '--header-bg': mix(t['--bg'], 90), '--sat-glass': (t['--sat-glass'] || '150') + '%'
    };
  }
  function fullTokens(t, uiLang) { var d = derive(t, uiLang); var out = {}; for (var k in t) out[k] = t[k]; for (var j in d) out[j] = d[j]; return out; }
  function applyToRoot(t, uiLang) { var f = fullTokens(t, uiLang); for (var k in f) document.documentElement.style.setProperty(k, f[k]); }
  window.KM_THEME = { SUPPORTED_VERSIONS: SUPPORTED_VERSIONS, SCHEMA: SCHEMA, validate: validate, derive: derive, fullTokens: fullTokens, applyToRoot: applyToRoot, isColor: isColor, parseColor: parseColor, luminance: luminance, contrast: contrast };
  // Az ügyfél-arculat KÜLÖN megjelenési tartomány: semleges alapértékei nem a SaaS-témából jönnek.
  window.KM_BRAND_DEFAULTS = {
    primary: '#4a4a4a', secondary: '#9a9a9a', bg: '#f2f2ef',
    fontHead: 'Georgia, serif', fontBody: 'system-ui, sans-serif',
    radius: 8, lang: 'hu', temp: true
  };
})();
